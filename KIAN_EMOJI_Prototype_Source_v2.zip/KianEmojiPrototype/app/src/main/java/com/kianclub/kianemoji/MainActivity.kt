package com.kianclub.kianemoji

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var result: TextView
    private val speechRequest = 41
    private val audioPermissionRequest = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFFF7F5F0.toInt())
        }
        root.addView(TextView(this).apply {
            text = "KIAN EMOJI 👑"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(0xFF6B4B12.toInt())
        })
        root.addView(TextView(this).apply {
            text = "متنت را بنویس یا با میکروفون فارسی صحبت کن؛ بعد ایموجی‌های مرتبط را بگیر."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 18)
        })
        editor = EditText(this).apply {
            hint = "اینجا بنویس... مثلا امروز خیلی خوشحالم"
            minLines = 3
            gravity = Gravity.TOP
            textSize = 18f
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(editor, LinearLayout.LayoutParams(-1, -2))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(makeButton("🎙 گفتار فارسی") { startSpeech() }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(makeButton("✨ تبدیل به ایموجی") { convertText() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(actions)
        result = TextView(this).apply {
            text = "ایموجی‌های پیشنهادی اینجا نمایش داده می‌شوند."
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(8, 24, 8, 24)
        }
        root.addView(result)
        root.addView(makeButton("کپی متن و ایموجی") {
            val value = editor.text.toString() + " " + result.text.toString()
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("KIAN EMOJI", value))
            Toast.makeText(this, "کپی شد", Toast.LENGTH_SHORT).show()
        })
        root.addView(makeButton("اشتراک‌گذاری") {
            val value = editor.text.toString() + " " + result.text.toString()
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, value)
            }, "اشتراک‌گذاری"))
        })
        root.addView(makeButton("فعال‌سازی کیبورد KIAN EMOJI") {
            startActivity(Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        root.addView(makeButton("انتخاب کیبورد برای تایپ") {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 14f; setOnClickListener { action() }
    }

    private fun startSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "سرویس تشخیص گفتار روی گوشی در دسترس نیست.", Toast.LENGTH_LONG).show(); return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest); return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "فارسی صحبت کن")
        }
        try { startActivityForResult(intent, speechRequest) }
        catch (_: Exception) { Toast.makeText(this, "شروع تشخیص گفتار ممکن نشد.", Toast.LENGTH_LONG).show() }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) { editor.append(spoken); convertText() }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startSpeech()
        else if (requestCode == audioPermissionRequest) Toast.makeText(this, "برای استفاده از میکروفون باید مجوز صدا را بدهی.", Toast.LENGTH_LONG).show()
    }

    private fun convertText() {
        val t = editor.text.toString().lowercase(Locale.ROOT)
        val emojis = linkedSetOf<String>()
        val rules = listOf(
            listOf("خوشحال", "شاد", "عالی", "خوب", "happy") to "😊 😍 🎉",
            listOf("عشق", "دوستت دارم", "عاشق", "قلب") to "❤️ 🥰 💕",
            listOf("سگ", "توله", "هاپو", "پاپی") to "🐶 🐾 ❤️",
            listOf("گربه", "پیشی") to "🐱 🐾",
            listOf("غمگین", "ناراحت", "دلتنگ", "گریه") to "😔 💔 🥺",
            listOf("خنده", "خندید", "بامزه", "جوک") to "😂 🤣 😹",
            listOf("ممنون", "متشکرم", "سپاس") to "🙏 ❤️",
            listOf("تبریک", "تولد", "موفقیت") to "🎉 🎂 🥳",
            listOf("آموزش", "یادگیری", "تمرین") to "📚 💡 ✨",
            listOf("خسته", "خواب", "شب بخیر") to "😴 🌙",
            listOf("غذا", "گرسنه", "خوراک") to "🍕 😋",
            listOf("سفر", "مسافرت", "دریا") to "✈️ 🌊 🌴"
        )
        rules.forEach { (words, icons) -> if (words.any { t.contains(it) }) emojis.addAll(icons.split(" ")) }
        if (emojis.isEmpty()) emojis.addAll(listOf("✨", "💬", "😊"))
        result.text = emojis.joinToString(" ")
    }
}
