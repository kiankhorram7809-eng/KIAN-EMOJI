package com.kianclub.kianemoji

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class KianEmojiIme : InputMethodService() {
    private val rows = listOf("ض ص ث ق ف غ ع ه خ ح ج چ", "ش س ی ب ل ا ت ن م ک گ", "ظ ط ز ر ذ د پ و")
    private val quickEmojis = listOf("😊", "❤️", "😂", "😍", "🐶", "🐾", "🥺", "🙏", "🎉", "✨", "😎", "🌹")

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(5, 8, 5, 8)
            setBackgroundColor(Color.rgb(31, 32, 36))
        }
        root.addView(TextView(this).apply {
            text = "KIAN CLUB  👑     ایموجی و تایپ فارسی"
            textSize = 16f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(240, 202, 105)); setPadding(0, 4, 0, 10)
        })
        val emojiRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        quickEmojis.forEach { emoji -> emojiRow.addView(key(emoji) { commit(emoji) }, LinearLayout.LayoutParams(0, 46, 1f)) }
        root.addView(emojiRow)
        rows.forEach { row ->
            val line = LinearLayout(this).apply { gravity = Gravity.CENTER }
            row.split(" ").forEach { letter -> line.addView(key(letter) { commit(letter) }, LinearLayout.LayoutParams(0, 48, 1f)) }
            root.addView(line)
        }
        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        bottom.addView(key("؟123") { commit("؟") }, LinearLayout.LayoutParams(0, 48, 1f))
        bottom.addView(key("فاصله") { commit(" ") }, LinearLayout.LayoutParams(0, 48, 3f))
        bottom.addView(key("⌫") { currentInputConnection?.deleteSurroundingText(1, 0) }, LinearLayout.LayoutParams(0, 48, 1f))
        bottom.addView(key("↵") { currentInputConnection?.performEditorAction(currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_DONE) }, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(bottom)
        root.addView(Button(this).apply {
            text = "باز کردن تبدیل گفتار و متن به ایموجی"
            setOnClickListener {
                val i = packageManager.getLaunchIntentForPackage(packageName)
                i?.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                if (i != null) startActivity(i)
            }
        })
        return root
    }

    private fun key(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 16f; isAllCaps = false
        setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(65, 67, 74))
        setPadding(0, 0, 0, 0); setOnClickListener { action() }
    }

    private fun commit(value: String) { currentInputConnection?.commitText(value, 1) }
}
