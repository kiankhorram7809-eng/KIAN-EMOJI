# KIAN EMOJI — Android prototype

A minimal Android IME prototype that attempts to insert a PNG using Android's
InputConnection content-commit API. It is deliberately a technical test, not
a finished emoji keyboard.

## Build
Requires JDK 17 and Android SDK 35. Run:

    gradle :app:assembleDebug

Or push to GitHub and run **Actions → Build KIAN EMOJI APK**. The APK is uploaded
as the workflow artifact `KIAN-EMOJI-test-apk`.

## Install and test
1. Install the debug APK on an Android test phone.
2. Open KIAN EMOJI once.
3. Enable it under Android Settings → System/General management → Keyboard list.
4. In a compatible text field, choose KIAN EMOJI from the keyboard picker.
5. Tap “ارسال تصویر آزمایشی”.
6. Repeat in WhatsApp and Telegram, then Instagram if desired.

## Important limitations
- This prototype only sends a sample face image.
- The destination app must advertise support for `image/png` content from an IME.
- A successful insertion may appear as an image attachment rather than inline text.
- Some apps may reject the content. This is expected and is exactly what the prototype tests.
- Do not enter passwords or sensitive text while this test keyboard is selected.
- This is source code for a test build, not a signed Play Store release.
