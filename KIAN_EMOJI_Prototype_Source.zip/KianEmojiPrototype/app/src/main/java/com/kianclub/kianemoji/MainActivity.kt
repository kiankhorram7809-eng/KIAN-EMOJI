package com.kianclub.kianemoji

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        layout.addView(TextView(this).apply {
            text = "KIAN EMOJI — نسخه آزمایشی\n\nاین نسخه فقط یک تصویر نمونه دارد و هنوز تصویر چهره شخصی شما در آن قرار نگرفته است.\n\n۱) فعال‌سازی کیبورد\n۲) انتخاب KIAN EMOJI هنگام تایپ\n۳) زدن دکمه «ارسال تصویر آزمایشی»\n۴) بررسی نتیجه در برنامه مقصد"
            textSize = 18f
        })
        layout.addView(Button(this).apply {
            text = "رفتن به تنظیمات کیبوردها"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "انتخاب کیبورد برای آزمایش"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        })
        setContentView(layout)
    }
}
