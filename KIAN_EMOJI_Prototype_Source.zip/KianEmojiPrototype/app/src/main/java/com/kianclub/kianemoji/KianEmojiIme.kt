package com.kianclub.kianemoji

import android.inputmethodservice.InputMethodService
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import java.io.File
import java.io.FileOutputStream

class KianEmojiIme : InputMethodService() {
    override fun onCreateInputView(): View {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(16, 18, 16, 18)
            setBackgroundColor(Color.rgb(24, 24, 24))
        }
        layout.addView(TextView(this).apply {
            text = "KIAN CLUB  👑"
            textSize = 20f
            setTextColor(Color.rgb(225, 190, 95))
            gravity = Gravity.CENTER
        })
        layout.addView(TextView(this).apply {
            text = "نسخه آزمایشی درج تصویر"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 12)
        })
        layout.addView(Button(this).apply {
            text = "🙂  ارسال تصویر آزمایشی"
            setOnClickListener { sendTestImage() }
        })
        layout.addView(TextView(this).apply {
            text = "اگر برنامه مقصد از درج تصویر توسط کیبورد پشتیبانی کند، تصویر در کادر پیام قرار می‌گیرد."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(4, 12, 4, 0)
        })
        return layout
    }

    private fun sendTestImage() {
        val editorInfo = currentInputEditorInfo
        val connection = currentInputConnection
        if (editorInfo == null || connection == null) {
            android.widget.Toast.makeText(this, "کادر ورودی فعالی پیدا نشد.", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val accepted = EditorInfoCompat.getContentMimeTypes(editorInfo).any {
            it == "image/png" || it == "image/*"
        }
        if (!accepted) {
            android.widget.Toast.makeText(this, "این برنامه درج تصویر از کیبورد را اعلام نکرده است.", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        try {
            val dir = File(cacheDir, "images").apply { mkdirs() }
            val file = File(dir, "kian-emoji-test.png")
            createSampleBitmap().compress(Bitmap.CompressFormat.PNG, 100, FileOutputStream(file))
            val uri: Uri = FileProvider.getUriForFile(
                this, "com.kianclub.kianemoji.fileprovider", file
            )
            val description = android.content.ClipDescription(
                "KIAN EMOJI test", arrayOf("image/png")
            )
            val content = InputContentInfoCompat(uri, description, null)
            val ok = InputConnectionCompat.commitContent(
                connection,
                editorInfo,
                content,
                InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION,
                Bundle()
            )
            if (!ok) {
                android.widget.Toast.makeText(this, "برنامه مقصد تصویر را نپذیرفت.", android.widget.Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "خطا در ارسال تصویر: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private fun createSampleBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.rgb(245, 195, 65)
        c.drawCircle(128f, 128f, 112f, p)
        p.color = Color.rgb(45, 35, 25)
        c.drawCircle(88f, 105f, 12f, p)
        c.drawCircle(168f, 105f, 12f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 10f
        c.drawArc(82f, 105f, 174f, 190f, 15f, 150f, false, p)
        return bmp
    }
}
